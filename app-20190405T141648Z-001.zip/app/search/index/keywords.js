define(function() {var keywords=[{w:"Expense",p:["p0"]},{w:"Forms",p:["p0"]},{w:"Human",p:["p1"]},{w:"Resources",p:["p1"]},{w:"Refresher",p:["p1"]},{w:"Check",p:["p2"]},{w:"Request",p:["p2"]}];
var ph={};
ph["p0"]=[0, 1];
ph["p1"]=[2, 3, 4];
ph["p2"]=[5, 6];
     return {
         keywords: keywords,
         ph: ph
     }
});
